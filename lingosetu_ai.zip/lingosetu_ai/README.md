# LingoSetu AI

A Flutter app for multilingual translation and language learning across
**English, Gujarati, Telugu, and Kannada** — built from the LingoSetu AI
architecture diagram (User → Flutter UI → Text/Voice/Image input →
Language ID & Preprocessing → Multilingual Translation Engine → Output →
Firebase backend).

The app **runs immediately** with a built-in mock translation engine —
no backend or AI model required to try it out. A companion FastAPI
backend is included and pre-wired so you can swap in a real Hugging
Face/PyTorch model later without touching the Flutter UI.

---

## 1. Project structure

```
lingosetu_ai/
├── lib/
│   ├── main.dart                 # Entry point, Firebase init + fallback screen
│   ├── app.dart                  # MaterialApp + AuthGate (routes by auth state)
│   ├── firebase_options.dart     # Placeholder — replace via `flutterfire configure`
│   ├── models/                   # Plain Dart data models
│   │   ├── language_model.dart
│   │   ├── translation_model.dart
│   │   └── user_model.dart
│   ├── services/                 # All external I/O lives here
│   │   ├── api_client.dart       # Talks to the FastAPI backend
│   │   ├── translation_service.dart  # Mock engine + real-API switch
│   │   ├── speech_service.dart   # Speech-to-text
│   │   ├── ocr_service.dart      # Image → text (ML Kit)
│   │   ├── tts_service.dart      # Text-to-speech
│   │   ├── auth_service.dart     # Firebase Auth
│   │   └── firestore_service.dart # History, profile, progress
│   ├── screens/
│   │   ├── splash_screen.dart
│   │   ├── auth/login_screen.dart, signup_screen.dart
│   │   ├── home_screen.dart      # Bottom-nav shell
│   │   ├── translate_screen.dart # Core feature screen
│   │   ├── history_screen.dart
│   │   ├── progress_screen.dart
│   │   └── profile_screen.dart
│   ├── widgets/                  # Reusable UI pieces
│   └── theme/app_theme.dart      # Material 3 theme
├── backend/                      # FastAPI translation service
│   ├── main.py
│   ├── engine.py                 # MockEngine (default) + TransformerEngine slot
│   └── requirements.txt
├── test/widget_test.dart
├── pubspec.yaml
└── README.md
```

---

## 2. Run the app immediately (mock mode)

No backend, no Firebase project required to explore the UI:

```bash
flutter pub get
flutter run
```

The `TranslationService` ships with `useMockEngine = true` by default and
includes a small curated phrase dictionary (hello, thank you, etc.) plus a
deterministic fallback for any other text, so every screen is fully
functional out of the box.

> Firebase Auth screens will show a "Firebase setup needed" message until
> you complete step 3 below — everything else (translation, TTS, STT, OCR
> pickers) works without it.

---

## 3. Firebase setup

1. Create a project at [console.firebase.google.com](https://console.firebase.google.com).
2. Enable **Authentication → Email/Password** and **Firestore Database**.
3. Install the FlutterFire CLI and configure the project:
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   This overwrites `lib/firebase_options.dart` with your real project
   config and registers Android/iOS/web apps automatically.
4. Recommended Firestore security rules (users can only read/write their
   own data):
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{userId} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
         match /translations/{translationId} {
           allow read, write: if request.auth != null && request.auth.uid == userId;
         }
       }
     }
   }
   ```
5. Re-run `flutter run`.

---

## 4. Run the FastAPI backend (optional — real engine)

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Point the Flutter app at it:

```bash
flutter run --dart-define=API_BASE_URL=http://<your-machine-ip>:8000
```

- On an Android **emulator**, `http://10.0.2.2:8000` (the default) already
  reaches your host machine's `localhost:8000`.
- On a **physical device**, use your computer's LAN IP instead.

`TranslationService.autoDetectEngine()` pings `/health` on startup; if the
backend responds it automatically prefers the live API over the mock, and
falls back to mock again if a request ever fails mid-session — so the app
never gets stuck.

### Swapping in a real AI model

`backend/engine.py` defines `BaseEngine`, `MockEngine` (active by default),
and a `TransformerEngine` stub ready for a Hugging Face/PyTorch model such
as `ai4bharat/indictrans2` or `facebook/nllb-200`:

```bash
pip install torch transformers sentencepiece   # uncomment in requirements.txt
```

Fill in `TransformerEngine._load_model` / `.translate`, then run with:

```bash
ENGINE=transformer uvicorn main:app --reload --port 8000
```

No Flutter code changes needed — `main.py`'s routes are engine-agnostic.
This is also where **transfer learning, fine-tuning, and data
augmentation** pipelines from the architecture diagram would plug in: train
offline, save a checkpoint, and load it in `_load_model`.

---

## 5. Key features implemented

| Diagram stage | Implementation |
|---|---|
| Text / Voice / Image input | `InputModeToggle` + `TranslateScreen` |
| Speech-to-Text | `speech_to_text` via `SpeechService` |
| OCR | `google_mlkit_text_recognition` via `OcrService` |
| Language Identification & Preprocessing | `TranslationService._detectLanguage` (mock) / `/api/v1/detect-language` (backend) |
| Multilingual Translation Engine | `TranslationService` (mock) ↔ `ApiClient` → FastAPI `engine.py` |
| Translation Output + Text-to-Speech | `TranslationCard` + `flutter_tts` via `TtsService` |
| Translation History | Firestore `users/{uid}/translations`, `HistoryScreen` |
| User Data / Profile | Firebase Auth + Firestore `users/{uid}`, `ProfileScreen` |
| Learning Progress | `ProgressScreen` with weekly activity chart (`fl_chart`) |
| Backend & Data Storage | Firebase (Auth + Firestore) + FastAPI backend |

---

## 6. Error handling notes

- All service calls (`AuthService`, `TranslationService`, `SpeechService`,
  `OcrService`, `FirestoreService`) throw typed exceptions with
  human-readable messages, caught in the UI and shown via SnackBars or
  inline banners — never silent failures.
- `TranslationService` falls back to the mock engine automatically if the
  live backend is unreachable, so a dropped connection never blocks
  translation.
- `main.dart` catches Firebase init failures and shows a guided setup
  screen instead of crashing.

---

## 7. Platform permissions

Add these before building for real devices (already assumed by the
plugins used):

**Android** (`android/app/src/main/AndroidManifest.xml`):
```xml
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.CAMERA"/>
```

**iOS** (`ios/Runner/Info.plist`):
```xml
<key>NSMicrophoneUsageDescription</key>
<string>LingoSetu AI needs microphone access for voice translation.</string>
<key>NSSpeechRecognitionUsageDescription</key>
<string>LingoSetu AI needs speech recognition for voice input.</string>
<key>NSCameraUsageDescription</key>
<string>LingoSetu AI needs camera access to scan text for translation.</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>LingoSetu AI needs photo access to translate text from images.</string>
```

---

## 8. Tests

```bash
flutter test
```

Covers `LanguageModel.byCode` and the `InputModeToggle` widget as a
starting point — extend with widget tests per screen as the app grows.
