import 'package:flutter_test/flutter_test.dart';
import 'package:lingosetu_ai/widgets/input_mode_toggle.dart';
import 'package:lingosetu_ai/models/language_model.dart';
import 'package:flutter/material.dart';

void main() {
  testWidgets('InputModeToggle renders all three modes', (tester) async {
    InputMode selected = InputMode.text;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: InputModeToggle(
            selected: selected,
            onChanged: (m) => selected = m,
          ),
        ),
      ),
    );

    expect(find.text('Text'), findsOneWidget);
    expect(find.text('Voice'), findsOneWidget);
    expect(find.text('Image'), findsOneWidget);
  });

  test('LanguageModel.byCode returns correct language', () {
    expect(LanguageModel.byCode('gu').name, 'Gujarati');
    expect(LanguageModel.byCode('te').name, 'Telugu');
    expect(LanguageModel.byCode('kn').name, 'Kannada');
    expect(LanguageModel.byCode('unknown').name, 'English');
  });
}
