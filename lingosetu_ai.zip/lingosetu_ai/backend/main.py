"""
LingoSetu AI - FastAPI backend
================================
Implements the "Multilingual Translation Engine" box from the architecture
diagram: Multilingual Model, Transfer Learning, Fine-Tuning, Data
Augmentation. Ships with a working mock engine so the API is usable
immediately; swap `engine.py`'s MockEngine for a real Hugging Face /
PyTorch transformer without changing any routes below.

Run locally:
    pip install -r requirements.txt
    uvicorn main:app --reload --port 8000

Then point the Flutter app at this server with:
    flutter run --dart-define=API_BASE_URL=http://<your-ip>:8000
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from engine import get_engine

app = FastAPI(
    title="LingoSetu AI Backend",
    description="Multilingual translation API for English, Gujarati, Telugu and Kannada.",
    version="1.0.0",
)

# Allow the Flutter app (mobile/web/emulator) to call this API during dev.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

engine = get_engine()

SUPPORTED_LANGUAGES = {"en", "gu", "te", "kn"}


class TranslateRequest(BaseModel):
    text: str
    source_lang: str  # 'auto' or a code in SUPPORTED_LANGUAGES
    target_lang: str


class TranslateResponse(BaseModel):
    translated_text: str
    detected_source_lang: str
    confidence: float
    engine: str


class DetectLanguageRequest(BaseModel):
    text: str


class DetectLanguageResponse(BaseModel):
    language: str
    confidence: float


@app.get("/health")
def health():
    """Used by the Flutter app's ApiClient.healthCheck() to decide whether
    to route through the live backend or fall back to its local mock."""
    return {"status": "ok", "engine": engine.name}


@app.post("/api/v1/translate", response_model=TranslateResponse)
def translate(req: TranslateRequest):
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="text must not be empty")
    if req.target_lang not in SUPPORTED_LANGUAGES:
        raise HTTPException(status_code=400, detail=f"Unsupported target_lang: {req.target_lang}")

    result = engine.translate(
        text=req.text,
        source_lang=req.source_lang,
        target_lang=req.target_lang,
    )
    return TranslateResponse(
        translated_text=result.translated_text,
        detected_source_lang=result.detected_source_lang,
        confidence=result.confidence,
        engine=engine.name,
    )


@app.post("/api/v1/detect-language", response_model=DetectLanguageResponse)
def detect_language(req: DetectLanguageRequest):
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="text must not be empty")
    lang, confidence = engine.detect_language(req.text)
    return DetectLanguageResponse(language=lang, confidence=confidence)
