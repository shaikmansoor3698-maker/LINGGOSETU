"""
Translation engine abstraction.

MockEngine works with zero setup so the backend runs immediately.
TransformerEngine is a ready-made slot for a real Hugging Face / PyTorch
multilingual model (e.g. facebook/nllb-200, ai4bharat/indictrans2) — fill
in `_load_model` and `_run_inference` and flip `get_engine()` to use it.
This mirrors the diagram: Multilingual Model + Transfer Learning +
Fine-Tuning + Data Augmentation all live behind this same interface.
"""
from __future__ import annotations

import os
import random
import re
from dataclasses import dataclass


@dataclass
class EngineResult:
    translated_text: str
    detected_source_lang: str
    confidence: float


class BaseEngine:
    name = "base"

    def translate(self, text: str, source_lang: str, target_lang: str) -> EngineResult:
        raise NotImplementedError

    def detect_language(self, text: str) -> tuple[str, float]:
        raise NotImplementedError


class MockEngine(BaseEngine):
    """Deterministic, dependency-free engine for local development and demos."""

    name = "mock-v1"

    PHRASES = {
        ("en", "gu"): {
            "hello": "નમસ્તે",
            "thank you": "આભાર",
            "how are you": "તમે કેમ છો",
            "good morning": "સુપ્રભાત",
        },
        ("en", "te"): {
            "hello": "నమస్కారం",
            "thank you": "ధన్యవాదాలు",
            "how are you": "మీరు ఎలా ఉన్నారు",
            "good morning": "శుభోదయం",
        },
        ("en", "kn"): {
            "hello": "ನಮಸ್ಕಾರ",
            "thank you": "ಧನ್ಯವಾದಗಳು",
            "how are you": "ನೀವು ಹೇಗಿದ್ದೀರಿ",
            "good morning": "ಶುಭೋದಯ",
        },
    }

    SCRIPT_RANGES = {
        "gu": (0x0A80, 0x0AFF),
        "te": (0x0C00, 0x0C7F),
        "kn": (0x0C80, 0x0CFF),
    }

    def detect_language(self, text: str) -> tuple[str, float]:
        counts = {"gu": 0, "te": 0, "kn": 0, "en": 0}
        for ch in text:
            code = ord(ch)
            matched = False
            for lang, (lo, hi) in self.SCRIPT_RANGES.items():
                if lo <= code <= hi:
                    counts[lang] += 1
                    matched = True
                    break
            if not matched and re.match(r"[A-Za-z]", ch):
                counts["en"] += 1
        lang = max(counts, key=counts.get)
        total = sum(counts.values()) or 1
        confidence = counts[lang] / total if total else 0.5
        return lang, round(max(confidence, 0.5), 2)

    def translate(self, text: str, source_lang: str, target_lang: str) -> EngineResult:
        detected = source_lang
        if source_lang == "auto":
            detected, _ = self.detect_language(text)

        phrase_map = self.PHRASES.get((detected, target_lang), {})
        hit = phrase_map.get(text.strip().lower())
        if hit:
            return EngineResult(translated_text=hit, detected_source_lang=detected, confidence=0.97)

        tag = {"gu": "ગુ", "te": "తె", "kn": "ಕನ", "en": "EN"}.get(target_lang, target_lang.upper())
        synthetic = f"[{tag}] {text}"
        rng = random.Random(hash(text) % (2**32))
        confidence = round(0.7 + rng.random() * 0.15, 2)
        return EngineResult(translated_text=synthetic, detected_source_lang=detected, confidence=confidence)


class TransformerEngine(BaseEngine):
    """
    Placeholder for the real Hugging Face / PyTorch multilingual model.

    Example wiring (uncomment and adapt once you've picked a model):

        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

        MODEL_NAME = "ai4bharat/indictrans2-en-indic-1B"

        def _load_model(self):
            self.tokenizer = AutoTokenizer.from_pretrained(self.MODEL_NAME, trust_remote_code=True)
            self.model = AutoModelForSeq2SeqLM.from_pretrained(self.MODEL_NAME, trust_remote_code=True)

    Fine-tuning / transfer learning / data augmentation scripts referenced
    in the architecture diagram would live in a separate `training/`
    directory and produce a checkpoint this class loads at startup.
    """

    name = "transformer-v1"

    def __init__(self):
        self._load_model()

    def _load_model(self):
        raise NotImplementedError(
            "Wire up your Hugging Face/PyTorch model here, then set "
            "ENGINE=transformer in the environment to activate it."
        )

    def translate(self, text: str, source_lang: str, target_lang: str) -> EngineResult:
        raise NotImplementedError

    def detect_language(self, text: str) -> tuple[str, float]:
        raise NotImplementedError


def get_engine() -> BaseEngine:
    """Selects engine implementation based on the ENGINE env var, defaulting
    to the dependency-free mock so `uvicorn main:app` works immediately."""
    choice = os.getenv("ENGINE", "mock").lower()
    if choice == "transformer":
        return TransformerEngine()
    return MockEngine()
