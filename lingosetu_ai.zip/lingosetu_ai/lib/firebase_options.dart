// File generated normally by the FlutterFire CLI (`flutterfire configure`).
//
// This is a PLACEHOLDER so the project compiles out of the box. Replace it
// by running `flutterfire configure` in the project root once you've
// created a Firebase project — see README.md "Firebase Setup".
//
// ignore_for_file: type=lint
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        return web;
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'REPLACE_ME',
    appId: 'REPLACE_ME',
    messagingSenderId: 'REPLACE_ME',
    projectId: 'lingosetu-ai-placeholder',
    authDomain: 'lingosetu-ai-placeholder.firebaseapp.com',
    storageBucket: 'lingosetu-ai-placeholder.appspot.com',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'REPLACE_ME',
    appId: 'REPLACE_ME',
    messagingSenderId: 'REPLACE_ME',
    projectId: 'lingosetu-ai-placeholder',
    storageBucket: 'lingosetu-ai-placeholder.appspot.com',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'REPLACE_ME',
    appId: 'REPLACE_ME',
    messagingSenderId: 'REPLACE_ME',
    projectId: 'lingosetu-ai-placeholder',
    storageBucket: 'lingosetu-ai-placeholder.appspot.com',
    iosBundleId: 'com.lingosetu.ai',
  );
}
