class AppConstants {
  static const String appName = 'LingoSetu AI';
  static const String tagline = 'Bridging languages, one word at a time.';

  // Firestore collections
  static const String usersCollection = 'users';
  static const String translationsSubcollection = 'translations';

  // Shared preferences keys
  static const String prefKeyTargetLanguage = 'preferred_target_language';
  static const String prefKeyOnboarded = 'has_onboarded';
}
