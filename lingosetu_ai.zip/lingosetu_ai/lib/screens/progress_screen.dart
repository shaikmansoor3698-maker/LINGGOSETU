import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/translation_model.dart';
import '../models/user_model.dart';
import '../services/firestore_service.dart';
import '../widgets/progress_chart.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  List<int> _weeklyCounts(List<TranslationModel> history) {
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final counts = List<int>.filled(7, 0);
    for (final t in history) {
      final diff = t.createdAt.difference(
        DateTime(startOfWeek.year, startOfWeek.month, startOfWeek.day),
      );
      final dayIndex = diff.inDays;
      if (dayIndex >= 0 && dayIndex < 7) {
        counts[dayIndex]++;
      }
    }
    return counts;
  }

  Map<String, int> _languageBreakdown(List<TranslationModel> history) {
    final map = <String, int>{};
    for (final t in history) {
      map[t.targetLanguageCode] = (map[t.targetLanguageCode] ?? 0) + 1;
    }
    return map;
  }

  @override
  Widget build(BuildContext context) {
    final firestoreService = FirestoreService();
    final user = FirebaseAuth.instance.currentUser;
    final scheme = Theme.of(context).colorScheme;

    if (user == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Progress')),
        body: const Center(child: Text('Sign in to track your progress')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Learning Progress')),
      body: StreamBuilder<UserModel?>(
        stream: firestoreService.watchUserProfile(user.uid),
        builder: (context, userSnap) {
          return StreamBuilder<List<TranslationModel>>(
            stream: firestoreService.watchHistory(user.uid),
            builder: (context, historySnap) {
              final history = historySnap.data ?? [];
              final profile = userSnap.data;
              final weekly = _weeklyCounts(history);
              final breakdown = _languageBreakdown(history);

              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: _StatCard(
                          icon: Icons.translate_rounded,
                          label: 'Total translations',
                          value: '${profile?.totalTranslations ?? history.length}',
                          color: scheme.primary,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _StatCard(
                          icon: Icons.local_fire_department_rounded,
                          label: 'Day streak',
                          value: '${profile?.streakDays ?? 0}',
                          color: Colors.orange,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('This week', style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 8),
                          ProgressChart(weeklyCounts: weekly),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Languages practiced',
                              style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 12),
                          if (breakdown.isEmpty)
                            Text('No data yet — start translating!',
                                style: TextStyle(color: scheme.onSurfaceVariant))
                          else
                            ...breakdown.entries.map((e) => Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 4),
                                  child: Row(
                                    children: [
                                      Expanded(child: Text(e.key.toUpperCase())),
                                      Text('${e.value} translations',
                                          style: const TextStyle(fontWeight: FontWeight.w600)),
                                    ],
                                  ),
                                )),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color),
            const SizedBox(height: 10),
            Text(value,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(label, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}
