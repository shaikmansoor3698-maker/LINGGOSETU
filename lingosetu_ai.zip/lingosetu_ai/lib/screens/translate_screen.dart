import 'dart:io';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/language_model.dart';
import '../models/translation_model.dart';
import '../services/translation_service.dart';
import '../services/speech_service.dart';
import '../services/ocr_service.dart';
import '../services/tts_service.dart';
import '../services/firestore_service.dart';
import '../widgets/language_selector.dart';
import '../widgets/translation_card.dart';
import '../widgets/input_mode_toggle.dart';

class TranslateScreen extends StatefulWidget {
  const TranslateScreen({super.key});

  @override
  State<TranslateScreen> createState() => _TranslateScreenState();
}

class _TranslateScreenState extends State<TranslateScreen> {
  final TranslationService _translationService = TranslationService();
  final SpeechService _speechService = SpeechService();
  final OcrService _ocrService = OcrService();
  final TtsService _ttsService = TtsService();
  final FirestoreService _firestoreService = FirestoreService();
  final TextEditingController _inputController = TextEditingController();
  final _uuid = const Uuid();

  LanguageModel _sourceLanguage = LanguageModel.english;
  LanguageModel _targetLanguage = LanguageModel.gujarati;
  InputMode _inputMode = InputMode.text;

  String _translatedText = '';
  bool _isTranslating = false;
  bool _isListening = false;
  bool _lastFromMock = false;
  File? _pickedImage;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    // Try to detect a live backend; falls back to mock automatically.
    _translationService.autoDetectEngine();
  }

  @override
  void dispose() {
    _inputController.dispose();
    _ocrService.dispose();
    super.dispose();
  }

  void _swapLanguages() {
    setState(() {
      final temp = _sourceLanguage;
      _sourceLanguage = _targetLanguage;
      _targetLanguage = temp;
      _translatedText = '';
    });
  }

  Future<void> _translateCurrentInput() async {
    final text = _inputController.text;
    if (text.trim().isEmpty) return;

    setState(() {
      _isTranslating = true;
      _errorMessage = null;
    });

    try {
      final result = await _translationService.translate(
        text: text,
        sourceLangCode: _sourceLanguage.code,
        targetLangCode: _targetLanguage.code,
      );

      setState(() {
        _translatedText = result.translatedText;
        _lastFromMock = result.fromMockEngine;
      });

      await _persistTranslation(text, result);
    } catch (e) {
      setState(() => _errorMessage = 'Translation failed: $e');
    } finally {
      if (mounted) setState(() => _isTranslating = false);
    }
  }

  Future<void> _persistTranslation(
      String sourceText, TranslationResult result) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return; // not signed in (shouldn't happen post-AuthGate)

    final record = TranslationModel(
      id: _uuid.v4(),
      sourceText: sourceText,
      translatedText: result.translatedText,
      sourceLanguageCode: _sourceLanguage.code,
      targetLanguageCode: _targetLanguage.code,
      inputSource: switch (_inputMode) {
        InputMode.text => InputSource.text,
        InputMode.voice => InputSource.voice,
        InputMode.image => InputSource.image,
      },
      createdAt: DateTime.now(),
      confidence: result.confidence,
    );

    try {
      await _firestoreService.saveTranslation(user.uid, record);
    } catch (_) {
      // Non-fatal: history sync failing shouldn't block the translation UX.
      // A production build would queue this for retry.
    }
  }

  Future<void> _startVoiceInput() async {
    setState(() => _errorMessage = null);
    try {
      setState(() => _isListening = true);
      await _speechService.startListening(
        localeId: _sttLocaleFor(_sourceLanguage.code),
        onResult: (text, isFinal) {
          setState(() => _inputController.text = text);
          if (isFinal) {
            setState(() => _isListening = false);
            _translateCurrentInput();
          }
        },
      );
    } catch (e) {
      setState(() {
        _isListening = false;
        _errorMessage = 'Voice input unavailable: $e';
      });
    }
  }

  Future<void> _stopVoiceInput() async {
    await _speechService.stopListening();
    setState(() => _isListening = false);
  }

  String _sttLocaleFor(String code) {
    switch (code) {
      case 'gu':
        return 'gu_IN';
      case 'te':
        return 'te_IN';
      case 'kn':
        return 'kn_IN';
      default:
        return 'en_IN';
    }
  }

  Future<void> _pickAndScanImage({required bool fromCamera}) async {
    setState(() => _errorMessage = null);
    try {
      final file = await _ocrService.pickImage(fromCamera: fromCamera);
      if (file == null) return;
      setState(() {
        _pickedImage = file;
        _isTranslating = true;
      });
      final extracted = await _ocrService.extractText(file);
      if (extracted.isEmpty) {
        setState(() {
          _isTranslating = false;
          _errorMessage = 'No text found in that image. Try a clearer photo.';
        });
        return;
      }
      _inputController.text = extracted;
      await _translateCurrentInput();
    } catch (e) {
      setState(() {
        _isTranslating = false;
        _errorMessage = 'Could not read image: $e';
      });
    }
  }

  Future<void> _speakTranslation() async {
    if (_translatedText.isEmpty) return;
    await _ttsService.speak(_translatedText, languageCode: _targetLanguage.code);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Translate')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Language picker row
              Row(
                children: [
                  Expanded(
                    child: LanguageSelector(
                      label: 'Translate from',
                      selected: _sourceLanguage,
                      options: LanguageModel.supported,
                      onChanged: (lang) => setState(() => _sourceLanguage = lang),
                    ),
                  ),
                  IconButton(
                    onPressed: _swapLanguages,
                    icon: const Icon(Icons.swap_horiz_rounded),
                    style: IconButton.styleFrom(
                      backgroundColor: scheme.primaryContainer,
                    ),
                  ),
                  Expanded(
                    child: LanguageSelector(
                      label: 'Translate to',
                      selected: _targetLanguage,
                      options: LanguageModel.supported,
                      onChanged: (lang) => setState(() => _targetLanguage = lang),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              InputModeToggle(
                selected: _inputMode,
                onChanged: (mode) => setState(() => _inputMode = mode),
              ),
              const SizedBox(height: 18),
              _buildInputArea(scheme),
              if (_errorMessage != null) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: scheme.errorContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.error_outline, color: scheme.onErrorContainer, size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(color: scheme.onErrorContainer, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 20),
              TranslationCard(
                text: _translatedText,
                languageLabel: '${_targetLanguage.flagEmoji} ${_targetLanguage.name}',
                isLoading: _isTranslating,
                showMockBadge: _translatedText.isNotEmpty && _lastFromMock,
                onSpeak: _translatedText.isEmpty ? null : _speakTranslation,
                onCopy: _translatedText.isEmpty
                    ? null
                    : () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Copied to clipboard (demo)')),
                        );
                      },
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInputArea(ColorScheme scheme) {
    switch (_inputMode) {
      case InputMode.text:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _inputController,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'Type text to translate…',
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () => setState(() {
                    _inputController.clear();
                    _translatedText = '';
                  }),
                ),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: _isTranslating ? null : _translateCurrentInput,
              icon: const Icon(Icons.translate_rounded),
              label: const Text('Translate'),
            ),
          ],
        );

      case InputMode.voice:
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Text(
                  _inputController.text.isEmpty
                      ? 'Tap the mic and start speaking'
                      : _inputController.text,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: _isListening ? _stopVoiceInput : _startVoiceInput,
                  child: CircleAvatar(
                    radius: 34,
                    backgroundColor:
                        _isListening ? scheme.error : scheme.primary,
                    child: Icon(
                      _isListening ? Icons.stop_rounded : Icons.mic_rounded,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  _isListening ? 'Listening… tap to stop' : 'Tap to speak',
                  style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12),
                ),
              ],
            ),
          ),
        );

      case InputMode.image:
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                if (_pickedImage != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.file(_pickedImage!, height: 160, fit: BoxFit.cover),
                  )
                else
                  Container(
                    height: 120,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: scheme.surfaceContainerHighest.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.image_outlined,
                        size: 40, color: scheme.onSurfaceVariant),
                  ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _pickAndScanImage(fromCamera: true),
                        icon: const Icon(Icons.photo_camera_outlined),
                        label: const Text('Camera'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _pickAndScanImage(fromCamera: false),
                        icon: const Icon(Icons.photo_library_outlined),
                        label: const Text('Gallery'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
    }
  }
}
