import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/translation_model.dart';
import '../services/firestore_service.dart';
import '../services/tts_service.dart';
import '../widgets/history_tile.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final FirestoreService _firestoreService = FirestoreService();
  final TtsService _ttsService = TtsService();

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: [
          if (user != null)
            IconButton(
              tooltip: 'Clear history',
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: () => _confirmClear(context, user.uid),
            ),
        ],
      ),
      body: user == null
          ? const Center(child: Text('Sign in to see your history'))
          : StreamBuilder<List<TranslationModel>>(
              stream: _firestoreService.watchHistory(user.uid),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        'Could not load history.\n${snapshot.error}',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }
                final items = snapshot.data ?? [];
                if (items.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'No translations yet.\nStart translating to build your history!',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final item = items[index];
                    return HistoryTile(
                      translation: item,
                      onTap: () => _ttsService.speak(
                        item.translatedText,
                        languageCode: item.targetLanguageCode,
                      ),
                      onDelete: () =>
                          _firestoreService.deleteTranslation(user.uid, item.id),
                    );
                  },
                );
              },
            ),
    );
  }

  void _confirmClear(BuildContext context, String uid) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear history?'),
        content: const Text('This will permanently delete all saved translations.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              _firestoreService.clearHistory(uid);
              Navigator.pop(ctx);
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }
}
