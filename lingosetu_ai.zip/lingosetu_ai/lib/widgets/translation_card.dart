import 'package:flutter/material.dart';

class TranslationCard extends StatelessWidget {
  final String text;
  final String languageLabel;
  final bool isLoading;
  final VoidCallback? onSpeak;
  final VoidCallback? onCopy;
  final bool showMockBadge;

  const TranslationCard({
    super.key,
    required this.text,
    required this.languageLabel,
    this.isLoading = false,
    this.onSpeak,
    this.onCopy,
    this.showMockBadge = false,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  languageLabel,
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                        color: scheme.primary,
                        fontWeight: FontWeight.w700,
                      ),
                ),
                if (showMockBadge) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: scheme.tertiaryContainer,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      'MOCK ENGINE',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: scheme.onTertiaryContainer,
                        letterSpacing: 0.4,
                      ),
                    ),
                  ),
                ],
                const Spacer(),
                if (onSpeak != null)
                  IconButton(
                    tooltip: 'Listen',
                    icon: const Icon(Icons.volume_up_outlined),
                    onPressed: onSpeak,
                  ),
                if (onCopy != null)
                  IconButton(
                    tooltip: 'Copy',
                    icon: const Icon(Icons.copy_outlined),
                    onPressed: onCopy,
                  ),
              ],
            ),
            const SizedBox(height: 6),
            isLoading
                ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Center(
                      child: SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(strokeWidth: 2.4),
                      ),
                    ),
                  )
                : Text(
                    text.isEmpty ? 'Translation will appear here…' : text,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: text.isEmpty
                              ? scheme.onSurfaceVariant
                              : scheme.onSurface,
                        ),
                  ),
          ],
        ),
      ),
    );
  }
}
