import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/translation_model.dart';
import '../models/language_model.dart';

class HistoryTile extends StatelessWidget {
  final TranslationModel translation;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;

  const HistoryTile({
    super.key,
    required this.translation,
    this.onTap,
    this.onDelete,
  });

  IconData get _sourceIcon {
    switch (translation.inputSource) {
      case InputSource.voice:
        return Icons.mic_none_rounded;
      case InputSource.image:
        return Icons.image_outlined;
      case InputSource.text:
        return Icons.keyboard_alt_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final source = LanguageModel.byCode(translation.sourceLanguageCode);
    final target = LanguageModel.byCode(translation.targetLanguageCode);

    return Card(
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        leading: CircleAvatar(
          backgroundColor: scheme.primaryContainer,
          child: Icon(_sourceIcon, color: scheme.onPrimaryContainer, size: 20),
        ),
        title: Text(
          translation.sourceText,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          translation.translatedText,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              '${source.flagEmoji}→${target.flagEmoji}',
              style: const TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 4),
            Text(
              DateFormat('MMM d, h:mm a').format(translation.createdAt),
              style: TextStyle(fontSize: 10, color: scheme.onSurfaceVariant),
            ),
          ],
        ),
        onLongPress: onDelete,
      ),
    );
  }
}
