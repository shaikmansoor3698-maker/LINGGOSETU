import 'package:flutter/material.dart';
import '../models/language_model.dart';

class LanguageSelector extends StatelessWidget {
  final LanguageModel selected;
  final List<LanguageModel> options;
  final ValueChanged<LanguageModel> onChanged;
  final String label;

  const LanguageSelector({
    super.key,
    required this.selected,
    required this.options,
    required this.onChanged,
    this.label = '',
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => _showPicker(context),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: scheme.surfaceContainerHighest.withOpacity(0.4),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: scheme.outlineVariant),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(selected.flagEmoji, style: const TextStyle(fontSize: 18)),
            const SizedBox(width: 8),
            Text(
              selected.name,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(width: 4),
            Icon(Icons.expand_more, size: 20, color: scheme.onSurfaceVariant),
          ],
        ),
      ),
    );
  }

  void _showPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              if (label.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(label,
                      style: Theme.of(context).textTheme.titleMedium),
                ),
              ...options.map((lang) => ListTile(
                    leading: Text(lang.flagEmoji,
                        style: const TextStyle(fontSize: 22)),
                    title: Text(lang.name),
                    subtitle: Text(lang.nativeName),
                    trailing: lang == selected
                        ? const Icon(Icons.check_circle, color: Colors.green)
                        : null,
                    onTap: () {
                      onChanged(lang);
                      Navigator.pop(ctx);
                    },
                  )),
              const SizedBox(height: 12),
            ],
          ),
        );
      },
    );
  }
}
