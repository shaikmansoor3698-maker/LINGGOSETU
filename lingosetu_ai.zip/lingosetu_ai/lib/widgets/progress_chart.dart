import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

/// Simple weekly-activity bar chart for the "Learning Progress" screen.
class ProgressChart extends StatelessWidget {
  final List<int> weeklyCounts; // 7 values, Mon..Sun
  final double maxY;

  const ProgressChart({
    super.key,
    required this.weeklyCounts,
    this.maxY = 10,
  }) : assert(weeklyCounts.length == 7);

  static const _labels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final computedMax = weeklyCounts.isEmpty
        ? maxY
        : (weeklyCounts.reduce((a, b) => a > b ? a : b) + 2).toDouble();

    return SizedBox(
      height: 180,
      child: BarChart(
        BarChartData(
          maxY: computedMax < maxY ? maxY : computedMax,
          gridData: const FlGridData(show: false),
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            leftTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            topTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            rightTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  final idx = value.toInt();
                  if (idx < 0 || idx >= _labels.length) return const SizedBox();
                  return Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      _labels[idx],
                      style: TextStyle(
                        fontSize: 12,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          barGroups: List.generate(weeklyCounts.length, (i) {
            return BarChartGroupData(
              x: i,
              barRods: [
                BarChartRodData(
                  toY: weeklyCounts[i].toDouble(),
                  color: scheme.primary,
                  width: 18,
                  borderRadius: BorderRadius.circular(6),
                ),
              ],
            );
          }),
        ),
      ),
    );
  }
}
