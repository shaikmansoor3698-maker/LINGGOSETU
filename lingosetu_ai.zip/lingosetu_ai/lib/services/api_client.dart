import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

/// Thin HTTP wrapper around the Python FastAPI backend described in the
/// architecture diagram (Multilingual Translation Engine: multilingual
/// model + transfer learning + fine-tuning + data augmentation).
///
/// This class does NOT contain any mock logic itself — it only knows how
/// to talk to a real server. [TranslationService] decides whether to call
/// this client or fall back to on-device mock translation, so swapping in
/// the real AI backend later means changing one flag, not rewriting UI code.
class ApiClient {
  /// Base URL of the FastAPI backend.
  /// Override at build time with:
  ///   flutter run --dart-define=API_BASE_URL=https://your-api.example.com
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000', // Android emulator -> localhost
  );

  final http.Client _client;
  final Duration timeout;

  ApiClient({http.Client? client, this.timeout = const Duration(seconds: 12)})
      : _client = client ?? http.Client();

  Future<Map<String, dynamic>> translate({
    required String text,
    required String sourceLang,
    required String targetLang,
  }) async {
    final uri = Uri.parse('$baseUrl/api/v1/translate');
    final response = await _client
        .post(
          uri,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'text': text,
            'source_lang': sourceLang,
            'target_lang': targetLang,
          }),
        )
        .timeout(timeout);

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    }
    throw ApiException(
      'Translation request failed (${response.statusCode})',
      statusCode: response.statusCode,
    );
  }

  Future<Map<String, dynamic>> detectLanguage(String text) async {
    final uri = Uri.parse('$baseUrl/api/v1/detect-language');
    final response = await _client
        .post(
          uri,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'text': text}),
        )
        .timeout(timeout);

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    }
    throw ApiException(
      'Language detection failed (${response.statusCode})',
      statusCode: response.statusCode,
    );
  }

  Future<bool> healthCheck() async {
    try {
      final uri = Uri.parse('$baseUrl/health');
      final response = await _client.get(uri).timeout(const Duration(seconds: 4));
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  void dispose() => _client.close();
}

class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, {this.statusCode});

  @override
  String toString() => 'ApiException: $message';
}
