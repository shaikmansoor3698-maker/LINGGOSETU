import 'package:flutter_tts/flutter_tts.dart';

/// Handles the "Text-to-Speech" output stage of the architecture diagram.
class TtsService {
  final FlutterTts _tts = FlutterTts();
  bool _configured = false;

  Future<void> _ensureConfigured() async {
    if (_configured) return;
    await _tts.setSpeechRate(0.45);
    await _tts.setPitch(1.0);
    await _tts.setVolume(1.0);
    _configured = true;
  }

  /// Maps app language codes to BCP-47 TTS locale tags.
  static const Map<String, String> _localeMap = {
    'en': 'en-IN',
    'gu': 'gu-IN',
    'te': 'te-IN',
    'kn': 'kn-IN',
  };

  Future<void> speak(String text, {required String languageCode}) async {
    if (text.trim().isEmpty) return;
    await _ensureConfigured();
    final locale = _localeMap[languageCode] ?? 'en-IN';
    try {
      await _tts.setLanguage(locale);
    } catch (_) {
      // Device may not have this locale's voice installed; fall back to
      // default rather than throwing, so speech is still attempted.
    }
    await _tts.speak(text);
  }

  Future<void> stop() async {
    await _tts.stop();
  }
}
