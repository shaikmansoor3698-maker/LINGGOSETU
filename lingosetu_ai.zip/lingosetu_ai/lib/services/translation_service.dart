import 'dart:math';
import 'api_client.dart';

/// Result returned by [TranslationService.translate].
class TranslationResult {
  final String translatedText;
  final String detectedSourceLanguage;
  final double confidence;
  final bool fromMockEngine;

  TranslationResult({
    required this.translatedText,
    required this.detectedSourceLanguage,
    required this.confidence,
    required this.fromMockEngine,
  });
}

/// Central translation service used by the whole app.
///
/// Maps directly onto the "Multilingual Translation Engine" box in the
/// architecture diagram. Today it runs a deterministic **mock engine** so
/// the app is fully usable offline and out of the box. Set [useMockEngine]
/// to `false` (or let the live API health check flip it automatically) to
/// route requests through [ApiClient] to the real FastAPI + Hugging
/// Face/PyTorch transformer backend instead — no other app code needs to
/// change, since both paths return the same [TranslationResult].
class TranslationService {
  final ApiClient _apiClient;
  bool useMockEngine;

  TranslationService({ApiClient? apiClient, this.useMockEngine = true})
      : _apiClient = apiClient ?? ApiClient();

  /// Pings the backend once at startup; if it's reachable, prefer the real
  /// engine automatically. Safe to call multiple times.
  Future<void> autoDetectEngine() async {
    final healthy = await _apiClient.healthCheck();
    useMockEngine = !healthy;
  }

  Future<TranslationResult> translate({
    required String text,
    required String sourceLangCode, // 'auto' allowed
    required String targetLangCode,
  }) async {
    final cleaned = text.trim();
    if (cleaned.isEmpty) {
      throw ArgumentError('Cannot translate empty text');
    }

    if (!useMockEngine) {
      try {
        final data = await _apiClient.translate(
          text: cleaned,
          sourceLang: sourceLangCode,
          targetLang: targetLangCode,
        );
        return TranslationResult(
          translatedText: data['translated_text'] as String? ?? '',
          detectedSourceLanguage:
              data['detected_source_lang'] as String? ?? sourceLangCode,
          confidence: (data['confidence'] as num?)?.toDouble() ?? 0.9,
          fromMockEngine: false,
        );
      } catch (_) {
        // Backend unreachable mid-session -> gracefully fall back to mock
        // so the user's flow is never blocked.
        return _mockTranslate(cleaned, sourceLangCode, targetLangCode);
      }
    }

    return _mockTranslate(cleaned, sourceLangCode, targetLangCode);
  }

  /// Lightweight on-device "translation" so the whole app works with zero
  /// backend setup. It combines: (1) a small curated phrase dictionary for
  /// realistic common-phrase demos, and (2) a deterministic pseudo-
  /// transliteration fallback for arbitrary text, so every input produces
  /// a plausible, stable result rather than an error.
  TranslationResult _mockTranslate(
    String text,
    String sourceLangCode,
    String targetLangCode,
  ) {
    final detected =
        sourceLangCode == 'auto' ? _detectLanguage(text) : sourceLangCode;

    final dictHit = _phraseBook[detected]?[targetLangCode]?[text.toLowerCase()];
    if (dictHit != null) {
      return TranslationResult(
        translatedText: dictHit,
        detectedSourceLanguage: detected,
        confidence: 0.97,
        fromMockEngine: true,
      );
    }

    final scriptTag = _scriptTagFor(targetLangCode);
    final synthetic = '[$scriptTag] $text';
    // Deterministic "confidence" so re-translating the same string in a
    // session always looks consistent rather than jittery.
    final confidence = 0.72 + (Random(text.hashCode).nextInt(15) / 100);

    return TranslationResult(
      translatedText: synthetic,
      detectedSourceLanguage: detected,
      confidence: confidence,
      fromMockEngine: true,
    );
  }

  String _scriptTagFor(String code) {
    switch (code) {
      case 'gu':
        return 'ગુ';
      case 'te':
        return 'తె';
      case 'kn':
        return 'ಕನ';
      case 'en':
      default:
        return 'EN';
    }
  }

  /// Extremely simple heuristic language detector for the mock engine:
  /// checks which Unicode block the majority of characters fall in.
  String _detectLanguage(String text) {
    int gu = 0, te = 0, kn = 0, en = 0;
    for (final rune in text.runes) {
      if (rune >= 0x0A80 && rune <= 0x0AFF) {
        gu++;
      } else if (rune >= 0x0C00 && rune <= 0x0C7F) {
        te++;
      } else if (rune >= 0x0C80 && rune <= 0x0CFF) {
        kn++;
      } else if (rune >= 0x0041 && rune <= 0x007A) {
        en++;
      }
    }
    final counts = {'gu': gu, 'te': te, 'kn': kn, 'en': en};
    return counts.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
  }

  /// Small curated dictionary covering common greetings/phrases so demos
  /// and manual QA show real, correct translations rather than only the
  /// synthetic fallback tag.
  static final Map<String, Map<String, Map<String, String>>> _phraseBook = {
    'en': {
      'gu': {
        'hello': 'નમસ્તે',
        'thank you': 'આભાર',
        'how are you': 'તમે કેમ છો',
        'good morning': 'સુપ્રભાત',
        'good night': 'શુભ રાત્રી',
        'welcome': 'સ્વાગત છે',
        'yes': 'હા',
        'no': 'ના',
      },
      'te': {
        'hello': 'నమస్కారం',
        'thank you': 'ధన్యవాదాలు',
        'how are you': 'మీరు ఎలా ఉన్నారు',
        'good morning': 'శుభోదయం',
        'good night': 'శుభ రాత్రి',
        'welcome': 'స్వాగతం',
        'yes': 'అవును',
        'no': 'కాదు',
      },
      'kn': {
        'hello': 'ನಮಸ್ಕಾರ',
        'thank you': 'ಧನ್ಯವಾದಗಳು',
        'how are you': 'ನೀವು ಹೇಗಿದ್ದೀರಿ',
        'good morning': 'ಶುಭೋದಯ',
        'good night': 'ಶುಭ ರಾತ್ರಿ',
        'welcome': 'ಸ್ವಾಗತ',
        'yes': 'ಹೌದು',
        'no': 'ಇಲ್ಲ',
      },
    },
    'gu': {
      'en': {
        'નમસ્તે': 'hello',
        'આભાર': 'thank you',
      },
    },
    'te': {
      'en': {
        'నమస్కారం': 'hello',
        'ధన్యవాదాలు': 'thank you',
      },
    },
    'kn': {
      'en': {
        'ನಮಸ್ಕಾರ': 'hello',
        'ಧನ್ಯವಾದಗಳು': 'thank you',
      },
    },
  };
}
