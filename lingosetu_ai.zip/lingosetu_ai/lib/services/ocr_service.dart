import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// Handles the "Image Input -> OCR" stage of the architecture diagram
/// using on-device ML Kit text recognition (works fully offline, and is
/// a reasonable stand-in until a custom Indic-script OCR model is
/// integrated on the backend).
class OcrService {
  final ImagePicker _picker = ImagePicker();
  final TextRecognizer _recognizer = TextRecognizer();

  Future<File?> pickImage({required bool fromCamera}) async {
    final XFile? file = await _picker.pickImage(
      source: fromCamera ? ImageSource.camera : ImageSource.gallery,
      imageQuality: 90,
    );
    if (file == null) return null;
    return File(file.path);
  }

  Future<String> extractText(File imageFile) async {
    try {
      final inputImage = InputImage.fromFile(imageFile);
      final RecognizedText result = await _recognizer.processImage(inputImage);
      return result.text.trim();
    } catch (e) {
      throw OcrServiceException('Could not extract text from image: $e');
    }
  }

  void dispose() {
    _recognizer.close();
  }
}

class OcrServiceException implements Exception {
  final String message;
  OcrServiceException(this.message);
  @override
  String toString() => message;
}
