import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/translation_model.dart';
import '../models/user_model.dart';

/// Wraps all Firestore reads/writes ("Backend & Data Storage" in the
/// architecture diagram: Translation History, User Data, Learning
/// Progress). All methods degrade gracefully — callers should still wrap
/// them in try/catch since Firestore calls can fail offline.
class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _users =>
      _db.collection('users');

  // ---------- User profile ----------

  Future<void> createUserProfile(UserModel user) async {
    await _users.doc(user.uid).set(user.toMap(), SetOptions(merge: true));
  }

  Future<UserModel?> getUserProfile(String uid) async {
    final doc = await _users.doc(uid).get();
    if (!doc.exists) return null;
    return UserModel.fromMap(doc.data()!);
  }

  Stream<UserModel?> watchUserProfile(String uid) {
    return _users.doc(uid).snapshots().map(
          (doc) => doc.exists ? UserModel.fromMap(doc.data()!) : null,
        );
  }

  Future<void> incrementTranslationCount(String uid) async {
    await _users.doc(uid).set({
      'totalTranslations': FieldValue.increment(1),
    }, SetOptions(merge: true));
  }

  // ---------- Translation history ----------

  CollectionReference<Map<String, dynamic>> _historyRef(String uid) =>
      _users.doc(uid).collection('translations');

  Future<void> saveTranslation(String uid, TranslationModel translation) async {
    await _historyRef(uid).doc(translation.id).set(translation.toMap());
    await incrementTranslationCount(uid);
  }

  Stream<List<TranslationModel>> watchHistory(String uid, {int limit = 100}) {
    return _historyRef(uid)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((snap) =>
            snap.docs.map((d) => TranslationModel.fromMap(d.data())).toList());
  }

  Future<void> deleteTranslation(String uid, String translationId) async {
    await _historyRef(uid).doc(translationId).delete();
  }

  Future<void> clearHistory(String uid) async {
    final batch = _db.batch();
    final docs = await _historyRef(uid).get();
    for (final doc in docs.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }
}
