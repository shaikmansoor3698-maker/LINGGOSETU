import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Wraps the `speech_to_text` plugin for the "Voice Input -> Speech-to-Text"
/// stage of the architecture diagram. Exposes a small, app-friendly API so
/// screens don't need to know about the plugin's internals.
class SpeechService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _initialized = false;
  bool get isListening => _speech.isListening;

  Future<bool> initialize() async {
    if (_initialized) return true;
    try {
      _initialized = await _speech.initialize(
        onError: (e) => print('SpeechService error: ${e.errorMsg}'),
        onStatus: (s) => print('SpeechService status: $s'),
      );
    } catch (e) {
      _initialized = false;
    }
    return _initialized;
  }

  /// Starts listening. [localeId] maps roughly to app language codes,
  /// e.g. 'gu_IN', 'te_IN', 'kn_IN', 'en_IN'.
  Future<void> startListening({
    required void Function(String recognizedText, bool isFinal) onResult,
    String localeId = 'en_IN',
  }) async {
    final available = await initialize();
    if (!available) {
      throw SpeechServiceException(
        'Speech recognition is not available on this device.',
      );
    }
    await _speech.listen(
      onResult: (result) {
        onResult(result.recognizedWords, result.finalResult);
      },
      localeId: localeId,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 4),
    );
  }

  Future<void> stopListening() async {
    if (_speech.isListening) {
      await _speech.stop();
    }
  }

  Future<void> cancel() async {
    if (_speech.isListening) {
      await _speech.cancel();
    }
  }
}

class SpeechServiceException implements Exception {
  final String message;
  SpeechServiceException(this.message);
  @override
  String toString() => message;
}
