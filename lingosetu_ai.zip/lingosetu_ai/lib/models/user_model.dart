/// App-level user profile, layered on top of Firebase Auth's user object.
/// Stored at `users/{uid}` in Firestore.
class UserModel {
  final String uid;
  final String displayName;
  final String email;
  final String preferredTargetLanguage; // e.g. "gu"
  final int totalTranslations;
  final int streakDays;
  final DateTime joinedAt;

  UserModel({
    required this.uid,
    required this.displayName,
    required this.email,
    this.preferredTargetLanguage = 'gu',
    this.totalTranslations = 0,
    this.streakDays = 0,
    required this.joinedAt,
  });

  UserModel copyWith({
    String? displayName,
    String? preferredTargetLanguage,
    int? totalTranslations,
    int? streakDays,
  }) {
    return UserModel(
      uid: uid,
      displayName: displayName ?? this.displayName,
      email: email,
      preferredTargetLanguage:
          preferredTargetLanguage ?? this.preferredTargetLanguage,
      totalTranslations: totalTranslations ?? this.totalTranslations,
      streakDays: streakDays ?? this.streakDays,
      joinedAt: joinedAt,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'displayName': displayName,
      'email': email,
      'preferredTargetLanguage': preferredTargetLanguage,
      'totalTranslations': totalTranslations,
      'streakDays': streakDays,
      'joinedAt': joinedAt.toIso8601String(),
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] as String? ?? '',
      displayName: map['displayName'] as String? ?? 'Learner',
      email: map['email'] as String? ?? '',
      preferredTargetLanguage:
          map['preferredTargetLanguage'] as String? ?? 'gu',
      totalTranslations: (map['totalTranslations'] as num?)?.toInt() ?? 0,
      streakDays: (map['streakDays'] as num?)?.toInt() ?? 0,
      joinedAt: DateTime.tryParse(map['joinedAt'] as String? ?? '') ??
          DateTime.now(),
    );
  }
}
