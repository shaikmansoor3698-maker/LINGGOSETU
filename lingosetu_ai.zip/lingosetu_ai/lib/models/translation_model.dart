import 'package:cloud_firestore/cloud_firestore.dart';

/// How the source text for a translation was captured.
enum InputSource { text, voice, image }

/// A single translation record, stored both locally (for instant history
/// display) and synced to Firestore under `users/{uid}/translations`.
class TranslationModel {
  final String id;
  final String sourceText;
  final String translatedText;
  final String sourceLanguageCode;
  final String targetLanguageCode;
  final InputSource inputSource;
  final DateTime createdAt;
  final double? confidence; // model confidence score, 0-1, if available

  TranslationModel({
    required this.id,
    required this.sourceText,
    required this.translatedText,
    required this.sourceLanguageCode,
    required this.targetLanguageCode,
    required this.inputSource,
    required this.createdAt,
    this.confidence,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'sourceText': sourceText,
      'translatedText': translatedText,
      'sourceLanguageCode': sourceLanguageCode,
      'targetLanguageCode': targetLanguageCode,
      'inputSource': inputSource.name,
      'createdAt': createdAt.toIso8601String(),
      'confidence': confidence,
    };
  }

  factory TranslationModel.fromMap(Map<String, dynamic> map) {
    final rawCreatedAt = map['createdAt'];
    DateTime parsedDate;
    if (rawCreatedAt is Timestamp) {
      parsedDate = rawCreatedAt.toDate();
    } else if (rawCreatedAt is String) {
      parsedDate = DateTime.tryParse(rawCreatedAt) ?? DateTime.now();
    } else {
      parsedDate = DateTime.now();
    }

    return TranslationModel(
      id: map['id'] as String? ?? '',
      sourceText: map['sourceText'] as String? ?? '',
      translatedText: map['translatedText'] as String? ?? '',
      sourceLanguageCode: map['sourceLanguageCode'] as String? ?? 'en',
      targetLanguageCode: map['targetLanguageCode'] as String? ?? 'en',
      inputSource: InputSource.values.firstWhere(
        (e) => e.name == map['inputSource'],
        orElse: () => InputSource.text,
      ),
      createdAt: parsedDate,
      confidence: (map['confidence'] as num?)?.toDouble(),
    );
  }
}
