/// Represents a language supported by LingoSetu AI.
///
/// Kept as a simple data class (rather than an enum) so new languages
/// can be added later without touching every switch statement — the
/// Multilingual Translation Engine in the architecture diagram is meant
/// to scale to more low-resource Indian languages over time.
class LanguageModel {
  final String code; // BCP-47 style code, e.g. "gu", "te", "kn", "en"
  final String name; // English display name
  final String nativeName; // Name written in the language's own script
  final String flagEmoji;

  const LanguageModel({
    required this.code,
    required this.name,
    required this.nativeName,
    required this.flagEmoji,
  });

  static const english = LanguageModel(
    code: 'en',
    name: 'English',
    nativeName: 'English',
    flagEmoji: '🇬🇧',
  );

  static const gujarati = LanguageModel(
    code: 'gu',
    name: 'Gujarati',
    nativeName: 'ગુજરાતી',
    flagEmoji: '🕌',
  );

  static const telugu = LanguageModel(
    code: 'te',
    name: 'Telugu',
    nativeName: 'తెలుగు',
    flagEmoji: '🛕',
  );

  static const kannada = LanguageModel(
    code: 'kn',
    name: 'Kannada',
    nativeName: 'ಕನ್ನಡ',
    flagEmoji: '🏯',
  );

  /// All languages the app currently supports, per the architecture diagram.
  static const List<LanguageModel> supported = [
    english,
    gujarati,
    telugu,
    kannada,
  ];

  static LanguageModel byCode(String code) {
    return supported.firstWhere(
      (l) => l.code == code,
      orElse: () => english,
    );
  }

  @override
  bool operator ==(Object other) =>
      other is LanguageModel && other.code == code;

  @override
  int get hashCode => code.hashCode;
}
