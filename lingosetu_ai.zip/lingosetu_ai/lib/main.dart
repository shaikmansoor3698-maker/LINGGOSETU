import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'app.dart';
import 'firebase_options.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  bool firebaseReady = true;
  String? firebaseError;
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    // Common on first run before `flutterfire configure` has been executed.
    // We still launch the app with a clear setup message instead of a
    // blank crash screen, so the rest of the UI remains inspectable.
    firebaseReady = false;
    firebaseError = e.toString();
  }

  runApp(firebaseReady
      ? const LingoSetuApp()
      : FirebaseSetupNeededApp(error: firebaseError));
}

/// Shown only if Firebase hasn't been configured yet. Guides the developer
/// to the README instead of leaving them with a crash or blank screen.
class FirebaseSetupNeededApp extends StatelessWidget {
  final String? error;
  const FirebaseSetupNeededApp({super.key, this.error});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      home: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.local_fire_department_outlined, size: 48),
                  const SizedBox(height: 16),
                  const Text(
                    'Firebase setup needed',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Run "flutterfire configure" and replace lib/firebase_options.dart '
                    'with your real project config, then relaunch. '
                    'See README.md → "Firebase Setup" for step-by-step instructions.',
                    textAlign: TextAlign.center,
                  ),
                  if (error != null) ...[
                    const SizedBox(height: 14),
                    Text(
                      error!,
                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
